# JARVIS Android Assistant (source project)

A free, dark-blue JARVIS-themed Android starter app with a British-English Android TTS voice, a foreground hands-free speech listener, spoken replies, basic time/date answers, reminder notifications, and a Wikipedia-summary lookup with Google Search fallback.

## Important honesty notes

- This ZIP contains **Android source code**, not a ready-to-install APK. The APK is produced by the included GitHub Actions workflow.
- The app needs a speech-recognition service on the phone (commonly Google Speech Services). Speech recognition may use the internet and may not work offline.
- Android does not guarantee reliable wake-word detection while the screen is off. This prototype uses Android's speech recognizer rather than a dedicated low-power wake-word engine. Keep the persistent JARVIS notification visible, exempt the app from battery optimisation if Android allows it, and test it while the screen is on first.
- General answers use the public Wikipedia summary endpoint. If no summary is found, the app opens a Google search. This is not a full ChatGPT-grade AI model.
- The app requests microphone permission. The microphone is used while hands-free mode is active; tap Deactivate Listening to stop it.
- Voice availability depends on installed Android speech voices. Set a UK English male voice in Android Settings > Text-to-speech output if one is available. Pitch is lowered in-app, but the app cannot guarantee a particular voice on every device.
- Reminders are scheduled as Android notifications. Exact alarm access and notification permission may be required by your Android version/settings.

## Build the APK using only your Android phone

1. Extract this ZIP.
2. Create a new GitHub repository in your browser.
3. Upload the **contents inside this folder** to the repository (not the outer ZIP). Make sure `.github/workflows/build-apk.yml` is included. If GitHub's mobile upload screen hides dot-folders, create the workflow in the repository using **Add file > Create new file**, name it `.github/workflows/build-apk.yml`, and paste the workflow contents from this ZIP.
4. Open the repository's **Actions** tab and select **Build JARVIS APK**. If it has not run automatically, tap **Run workflow**.
5. When the run finishes successfully, open that run and download the **JARVIS-Android-APK** artifact. GitHub downloads it as a ZIP; extract it to get `app-debug.apk`.
6. Tap the APK to install. Android may ask you to allow installation from that browser/files app.
7. Open JARVIS, grant microphone and notification permissions, then tap **ACTIVATE HANDS-FREE MODE** once. Say “Hey Jarvis,” wait for “Yes, sir?”, then ask a question.

## Supported voice examples

- “Hey Jarvis”
- “What time is it?”
- “What is today's date?”
- “Remind me to study in 10 minutes.”
- “Remind me to call mum at 7 PM.”
- “Who was Albert Einstein?” (Wikipedia summary when available)

## Troubleshooting

- If the microphone does not listen, check Android Settings > Apps > JARVIS > Permissions > Microphone, and make sure a speech recognition service is installed/enabled.
- If the service stops in the background, allow notifications and, if available, set JARVIS battery use to Unrestricted. Android versions differ and can still stop background microphone access.
- If reminders do not appear, allow JARVIS notifications and check Alarms & reminders access in Android settings.
- The British voice comes from Android's installed TTS engine, not a bundled licensed voice. Select English (United Kingdom) and a male voice in the system Text-to-speech settings if offered.
