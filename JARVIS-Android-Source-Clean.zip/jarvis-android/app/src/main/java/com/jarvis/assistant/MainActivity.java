package com.jarvis.assistant;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
    private TextView status, transcript;
    private Button startButton;
    private final int REQ = 42;
    private final BroadcastReceiver updates = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) {
            String state = i.getStringExtra("state");
            String text = i.getStringExtra("text");
            if (state != null) status.setText(state);
            if (text != null) transcript.setText(text);
        }
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        buildUi();
        IntentFilter f = new IntentFilter("com.jarvis.assistant.UPDATE");
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(updates, f, Context.RECEIVER_NOT_EXPORTED); else registerReceiver(updates, f);
        askPermissions();
    }
    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setGravity(Gravity.CENTER_HORIZONTAL); root.setPadding(28, 36, 28, 28); root.setBackgroundColor(Color.rgb(3,9,20)); scroll.addView(root);
        TextView eyebrow = new TextView(this); eyebrow.setText("STARK INDUSTRIES  •  PERSONAL ASSISTANT"); eyebrow.setTextColor(Color.rgb(0,217,255)); eyebrow.setTextSize(11); eyebrow.setGravity(Gravity.CENTER); root.addView(eyebrow);
        TextView title = new TextView(this); title.setText("J.A.R.V.I.S."); title.setTextColor(Color.WHITE); title.setTextSize(38); title.setTypeface(Typeface.DEFAULT, Typeface.BOLD); title.setGravity(Gravity.CENTER); title.setPadding(0, 22, 0, 4); root.addView(title);
        TextView sub = new TextView(this); sub.setText("VOICE INTERFACE  /  ONLINE SYSTEMS"); sub.setTextColor(Color.rgb(0,160,210)); sub.setTextSize(12); sub.setGravity(Gravity.CENTER); root.addView(sub);
        TextView orb = new TextView(this); orb.setText("◉"); orb.setTextColor(Color.rgb(0,217,255)); orb.setTextSize(100); orb.setGravity(Gravity.CENTER); orb.setPadding(0, 12, 0, 4); root.addView(orb);
        status = new TextView(this); status.setText("SYSTEM STANDBY"); status.setTextColor(Color.rgb(0,217,255)); status.setTextSize(16); status.setTypeface(Typeface.MONOSPACE, Typeface.BOLD); status.setGravity(Gravity.CENTER); status.setPadding(0, 8, 0, 18); root.addView(status);
        transcript = new TextView(this); transcript.setText("Good evening. JARVIS is ready.\n\nTap ACTIVATE once, then say ‘Hey Jarvis’ followed by your question. Keep the service notification visible while listening."); transcript.setTextColor(Color.rgb(205,225,240)); transcript.setTextSize(15); transcript.setGravity(Gravity.CENTER); transcript.setPadding(18, 20, 18, 20); transcript.setBackgroundColor(Color.rgb(8,22,38)); root.addView(transcript);
        startButton = new Button(this); startButton.setText("ACTIVATE HANDS-FREE MODE"); startButton.setTextColor(Color.BLACK); startButton.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(0,217,255))); LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, -2); bp.setMargins(0, 22, 0, 8); root.addView(startButton, bp);
        Button stop = new Button(this); stop.setText("DEACTIVATE LISTENING"); stop.setTextColor(Color.rgb(0,217,255)); stop.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(8,22,38))); root.addView(stop, new LinearLayout.LayoutParams(-1, -2));
        TextView note = new TextView(this); note.setText("Wake phrase: “Hey Jarvis”  •  Voice: English (United Kingdom)\nReminders are saved as Android notifications."); note.setTextColor(Color.GRAY); note.setTextSize(12); note.setGravity(Gravity.CENTER); note.setPadding(8, 20, 8, 4); root.addView(note);
        startButton.setOnClickListener(v -> { if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { askPermissions(); return; } Intent in = new Intent(this, JarvisService.class); in.setAction(JarvisService.ACTION_START); if (Build.VERSION.SDK_INT >= 26) startForegroundService(in); else startService(in); status.setText("INITIALISING VOICE SYSTEM..."); });
        stop.setOnClickListener(v -> { Intent in = new Intent(this, JarvisService.class); in.setAction(JarvisService.ACTION_STOP); startService(in); status.setText("SYSTEM STANDBY"); });
        setContentView(scroll);
    }
    private void askPermissions() {
        java.util.ArrayList<String> p = new java.util.ArrayList<>();
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) p.add(Manifest.permission.RECORD_AUDIO);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) p.add(Manifest.permission.POST_NOTIFICATIONS);
        if (!p.isEmpty()) requestPermissions(p.toArray(new String[0]), REQ);
    }
    @Override protected void onDestroy() { super.onDestroy(); try { unregisterReceiver(updates); } catch (Exception ignored) {} }
}
