package com.jarvis.assistant;

import android.app.*;
import android.content.*;
import android.os.Build;

public class ReminderReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        String task=intent.getStringExtra("task"); if(task==null||task.trim().isEmpty())task="your reminder";
        String channel="jarvis_reminders"; NotificationManager nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(new NotificationChannel(channel,"JARVIS reminders",NotificationManager.IMPORTANCE_HIGH));
        Notification n=new Notification.Builder(context,channel).setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("JARVIS reminder").setContentText("Sir, remember to "+task).setAutoCancel(true).build(); nm.notify(intent.getIntExtra("id",1),n);
    }
}
