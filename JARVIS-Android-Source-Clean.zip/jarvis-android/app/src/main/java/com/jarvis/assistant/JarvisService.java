package com.jarvis.assistant;

import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.os.*;
import android.speech.*;
import android.speech.tts.TextToSpeech;
import android.net.Uri;
import java.net.*;
import java.io.*;
import java.util.*;
import java.util.regex.*;
import org.json.JSONObject;

public class JarvisService extends Service implements TextToSpeech.OnInitListener {
    public static final String ACTION_START="JARVIS_START", ACTION_STOP="JARVIS_STOP";
    private SpeechRecognizer recognizer; private Intent speechIntent; private TextToSpeech tts; private boolean ready=false, active=false, waitingForQuestion=false, processing=false;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private static final String CHANNEL="jarvis_voice";

    @Override public void onCreate() { super.onCreate(); tts = new TextToSpeech(this, this); createChannel(); }
    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_START : intent.getAction();
        if (ACTION_STOP.equals(action)) { stopListening(); stopForeground(true); stopSelf(); return START_NOT_STICKY; }
        Notification n = new Notification.Builder(this, CHANNEL).setContentTitle("JARVIS is listening").setContentText("Say ‘Hey Jarvis’ to ask a question. Tap to open JARVIS.").setSmallIcon(android.R.drawable.ic_lock_silent_mode_off).setOngoing(true).build();
        if (Build.VERSION.SDK_INT >= 29) startForeground(7, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE); else startForeground(7,n);
        active = true; broadcast("LISTENING FOR ‘HEY JARVIS’", null); startRecognition(); return START_STICKY;
    }
    private void createChannel() { if (Build.VERSION.SDK_INT >= 26) { NotificationChannel c = new NotificationChannel(CHANNEL,"JARVIS voice assistant",NotificationManager.IMPORTANCE_LOW); ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c); } }
    @Override public void onInit(int status) { if (status == TextToSpeech.SUCCESS) { int r=tts.setLanguage(Locale.UK); tts.setSpeechRate(0.88f); tts.setPitch(0.78f); ready = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED; } }
    private void startRecognition() {
        if (!active || processing) return;
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { broadcast("Speech recognition is unavailable on this phone", "Install/enable a speech recognition service in Android settings."); return; }
        try {
            if (recognizer != null) { recognizer.destroy(); recognizer=null; }
            recognizer = SpeechRecognizer.createSpeechRecognizer(this);
            recognizer.setRecognitionListener(new RecognitionListener() {
                public void onReadyForSpeech(Bundle p) { broadcast(waitingForQuestion?"LISTENING FOR YOUR QUESTION":"LISTENING FOR ‘HEY JARVIS’",null); }
                public void onBeginningOfSpeech() {} public void onRmsChanged(float r) {} public void onBufferReceived(byte[] b) {} public void onEndOfSpeech() { }
                public void onError(int e) { if(active && !processing) handler.postDelayed(() -> startRecognition(), 650); }
                public void onResults(Bundle b) { handleResults(b); }
                public void onPartialResults(Bundle b) { }
                public void onEvent(int e, Bundle b) {}
            });
            speechIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH); speechIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); speechIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"en-GB"); speechIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE,"en-GB"); speechIntent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,true); speechIntent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS,3); recognizer.startListening(speechIntent);
        } catch (Exception ex) { handler.postDelayed(() -> startRecognition(), 1200); }
    }
    private void handleResults(Bundle b) {
        if (!active) return; ArrayList<String> results=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION); if(results==null||results.isEmpty()){handler.postDelayed(()->startRecognition(),400);return;}
        String spoken=results.get(0).trim(); String low=spoken.toLowerCase(Locale.UK);
        if (!waitingForQuestion) {
            if (low.contains("hey jarvis") || low.equals("jarvis") || low.startsWith("okay jarvis") || low.startsWith("ok jarvis")) {
                waitingForQuestion=true; broadcast("YES, SIR?", "You said: "+spoken+"\n\nListening for your question..."); say("Yes, sir?");
            }
            handler.postDelayed(()->startRecognition(), 900); return;
        }
        waitingForQuestion=false; processing=true; broadcast("PROCESSING REQUEST", "You: "+spoken); processRequest(spoken);
    }
    private void processRequest(String q) {
        String low=q.toLowerCase(Locale.UK).trim();
        if (low.matches(".*\\b(what time is it|tell me the time|current time)\\b.*")) { java.text.SimpleDateFormat f=new java.text.SimpleDateFormat("h:mm a",Locale.UK); finishAnswer("It is "+f.format(new Date())+", sir."); return; }
        if (low.matches(".*\\b(what is the date|what day is it|today's date|todays date)\\b.*")) { java.text.SimpleDateFormat f=new java.text.SimpleDateFormat("EEEE, d MMMM yyyy",Locale.UK); finishAnswer("Today is "+f.format(new Date())+", sir."); return; }
        if (low.contains("remind me") || low.startsWith("set a reminder")) { createReminder(q); return; }
        if (low.contains("stop listening") || low.contains("go to sleep")) { finishAnswer("Understood, sir. I am standing by."); handler.postDelayed(()->{ active=false; stopListening(); stopForeground(true); stopSelf(); },2500); return; }
        fetchAnswer(q);
    }
    private void fetchAnswer(String q) {
        new Thread(() -> {
            String answer=null;
            try {
                String cleaned=q.replaceFirst("(?i)^(hey jarvis[, ]*|jarvis[, ]*)","").trim();
                String url="https://en.wikipedia.org/api/rest_v1/page/summary/"+URLEncoder.encode(cleaned.replace(' ','_'),"UTF-8");
                HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection(); c.setConnectTimeout(5000); c.setReadTimeout(5000); c.setRequestProperty("User-Agent","JARVISAndroidAssistant/1.0 (personal assistant)");
                if(c.getResponseCode()==200) { BufferedReader r=new BufferedReader(new InputStreamReader(c.getInputStream())); StringBuilder s=new StringBuilder(); String line; while((line=r.readLine())!=null)s.append(line); JSONObject j=new JSONObject(s.toString()); if(j.has("extract")) answer=j.getString("extract"); r.close(); } c.disconnect();
            } catch(Exception ignored) {}
            final String a=answer;
            handler.post(() -> { if(a!=null && !a.trim().isEmpty()) finishAnswer(shorten(a,500)+". "); else { finishAnswer("I could not find a reliable answer, sir. I will open a web search for you."); try { Intent browser=new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q="+Uri.encode(q))); browser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(browser); } catch(Exception ignored) {} } });
        }).start();
    }
    private String shorten(String s,int max) { s=s.replaceAll("\\s+"," ").trim(); if(s.length()<=max)return s; int cut=s.lastIndexOf('.',max); if(cut>180)return s.substring(0,cut+1); return s.substring(0,max)+"…"; }
    private void createReminder(String spoken) {
        // Supported examples: "remind me to study in 10 minutes" or "remind me to call mum at 7 pm".
        Matcher in=Pattern.compile("(?i)\\b(in)\\s+(\\d+)\\s+(minute|minutes|hour|hours)\\b").matcher(spoken);
        long when=0; String task=spoken.replaceFirst("(?i)^.*?remind me to\\s*","").replaceFirst("(?i)^.*?set a reminder to\\s*","").trim();
        if(in.find()) { int n=Integer.parseInt(in.group(2)); when=System.currentTimeMillis()+n*(in.group(3).toLowerCase(Locale.UK).startsWith("hour")?3600000L:60000L); task=task.substring(0,Math.max(0,task.toLowerCase(Locale.UK).indexOf(in.group().toLowerCase(Locale.UK)))).replaceAll("(?i)\\s+at\\s*$","").trim(); }
        else {
            Matcher at=Pattern.compile("(?i)\\bat\\s+(\\d{1,2})(?::(\\d{2}))?\\s*(am|pm)\\b").matcher(spoken);
            if(at.find()) { Calendar cal=Calendar.getInstance(); int hour=Integer.parseInt(at.group(1))%12; if(at.group(3).equalsIgnoreCase("pm"))hour+=12; cal.set(Calendar.HOUR_OF_DAY,hour); cal.set(Calendar.MINUTE,at.group(2)==null?0:Integer.parseInt(at.group(2))); cal.set(Calendar.SECOND,0); cal.set(Calendar.MILLISECOND,0); if(cal.getTimeInMillis()<=System.currentTimeMillis())cal.add(Calendar.DAY_OF_YEAR,1); when=cal.getTimeInMillis(); task=spoken.replaceFirst("(?i)^.*?remind me to\\s*","").replaceFirst("(?i)\\s+at\\s+\\d{1,2}(:\\d{2})?\\s*(am|pm).*$","").trim(); }
        }
        if(when==0 || task.isEmpty()) { finishAnswer("Certainly, sir. Please say, remind me to study in ten minutes, or remind me to call mum at seven PM."); return; }
        int id=(int)(System.currentTimeMillis() & 0x7fffffff); Intent ri=new Intent(this,ReminderReceiver.class); ri.putExtra("task",task); ri.putExtra("id",id); PendingIntent pi=PendingIntent.getBroadcast(this,id,ri,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE); AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);
        try { if(Build.VERSION.SDK_INT>=23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi); else am.set(AlarmManager.RTC_WAKEUP,when,pi); java.text.SimpleDateFormat f=new java.text.SimpleDateFormat("h:mm a",Locale.UK); finishAnswer("Reminder set, sir. I will remind you to "+task+" at "+f.format(new Date(when))+"."); } catch(Exception e) { finishAnswer("I could not schedule that reminder. Please allow alarms and reminders in Android settings."); }
    }
    private void finishAnswer(String text) { processing=false; broadcast("JARVIS ONLINE", "JARVIS: "+text); say(text); long delay=Math.min(15000, Math.max(2800, text.length()*58L)); handler.postDelayed(() -> { if(active && !processing) startRecognition(); }, delay); }
    private void say(String text) { if(ready && tts!=null) tts.speak(text,TextToSpeech.QUEUE_FLUSH,null,"jarvis_speech"); }
    private void broadcast(String state,String text) { Intent i=new Intent("com.jarvis.assistant.UPDATE"); i.setPackage(getPackageName()); if(state!=null)i.putExtra("state",state); if(text!=null)i.putExtra("text",text); sendBroadcast(i); }
    private void stopListening() { active=false; if(recognizer!=null){try{recognizer.cancel();recognizer.destroy();}catch(Exception ignored){} recognizer=null;} }
    @Override public void onDestroy() { stopListening(); if(tts!=null){tts.stop();tts.shutdown();} super.onDestroy(); }
    @Override public android.os.IBinder onBind(Intent i){return null;}
}
